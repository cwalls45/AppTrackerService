"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApplicationEventGateway = void 0;
const aws_sdk_1 = __importDefault(require("aws-sdk"));
const dayjs_1 = __importDefault(require("dayjs"));
const formatChemicalAppToEvent_1 = require("../utils/formatChemicalAppToEvent");
class ApplicationEventGateway {
    constructor() {
        this.dynamoDb = new aws_sdk_1.default.DynamoDB.DocumentClient();
    }
    createApplication(application, accountId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const params = {
                    Item: {
                        pk: `application:${accountId}:${(0, dayjs_1.default)().year()}`,
                        sk: `application:${application.dateOfApplication}:${application.id}`,
                        data: application,
                        createdAt: (0, dayjs_1.default)().utc().toISOString(),
                    },
                    //TODO: make table name dynamic based on environment
                    TableName: 'TurfTracker-dev',
                };
                yield this.dynamoDb.put(params).promise();
                console.log(`Application created: ${JSON.stringify(application, null, 2)}`);
                return application;
            }
            catch (error) {
                console.log(`Error occured in creating application: ${JSON.stringify(error, null, 2)}`);
                throw new Error(`Error occured in creating application: ${JSON.stringify(error, null, 2)}`);
            }
        });
    }
    createApplicationEvent(application, accountId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const applicationEvent = (0, formatChemicalAppToEvent_1.formatChemicalApplicationToApplicationEvent)(application);
                const applicationEventForDynamo = Object.assign(Object.assign({}, applicationEvent), { start: (0, dayjs_1.default)(applicationEvent.start).toISOString(), end: (0, dayjs_1.default)(applicationEvent.end).toISOString() });
                const params = {
                    Item: {
                        pk: `applicationEvent:${accountId}:${(0, dayjs_1.default)().year()}`,
                        sk: `applicationEvent:${application.dateOfApplication}:${application.id}`,
                        data: applicationEventForDynamo,
                        createdAt: (0, dayjs_1.default)().utc().toISOString(),
                    },
                    //TODO: make table name dynamic based on environment
                    TableName: 'TurfTracker-dev'
                };
                yield this.dynamoDb.put(params).promise();
                console.log(`Application Event created: ${JSON.stringify(applicationEvent, null, 2)}`);
                return applicationEvent;
            }
            catch (error) {
                console.log(`Error occured in creating application event: ${JSON.stringify(error, null, 2)}`);
                throw new Error(`Error occured in creating application event: ${JSON.stringify(error, null, 2)}`);
            }
        });
    }
    getApplicationEventsByYear(year, accountId) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const params = {
                    //TODO: make table name dynamic based on environment
                    TableName: 'TurfTracker-dev',
                    KeyConditionExpression: "pk = :pk",
                    ExpressionAttributeValues: {
                        ":pk": `applicationEvent:${accountId}:${year}`,
                    },
                };
                // TODO: make sure there is not a more efficent way to get all application events
                const applicationEvents = yield this.dynamoDb.query(params).promise();
                //TODO: revist below to make this more clear
                console.log('applictationEvent', JSON.stringify(applicationEvents, null, 2));
                return (_a = applicationEvents.Items) === null || _a === void 0 ? void 0 : _a.map((appEvent) => (Object.assign({}, appEvent.data)));
            }
            catch (error) {
                console.log(`Error occured in fetching application event: ${JSON.stringify(error, null, 2)}`);
                throw new Error(`Error occured in fetching application event: ${JSON.stringify(error, null, 2)}`);
            }
        });
    }
}
exports.ApplicationEventGateway = ApplicationEventGateway;
//# sourceMappingURL=applicationEventGateway.js.map