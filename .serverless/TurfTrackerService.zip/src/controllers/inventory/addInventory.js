"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const addInventory = (req, res) => {
    try {
        //TODO: finish once database is set up
        console.log(req.body.inventory);
        res.send('Inventory Added');
    }
    catch (error) {
        console.log(error);
        res.status(400).send({ error: `There was an error adding inventory: ${req.body.inventory.companyName}` });
    }
};
exports.default = addInventory;
//# sourceMappingURL=addInventory.js.map