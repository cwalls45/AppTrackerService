"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const inventoryGateway_1 = require("../../gateways/inventoryGateway");
const addInventory = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        //TODO: finish once database is set up
        const inventoryGateway = new inventoryGateway_1.InventoryGateway();
        let { inventory, accountId } = req.body;
        const response = yield inventoryGateway.addInventory(inventory, accountId);
        res.locals.inventory = response;
        res.send(res.locals.inventory);
    }
    catch (error) {
        console.log(JSON.stringify(error, null, 2));
        res.status(400).send({ error: `There was an error adding inventory: ${req.body.inventory.companyName}` });
    }
});
exports.default = addInventory;
//# sourceMappingURL=addInventory.js.map