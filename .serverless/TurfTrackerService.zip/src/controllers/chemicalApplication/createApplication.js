"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const joi_1 = __importDefault(require("joi"));
const uuid_1 = require("uuid");
const chemicalApplication_1 = require("../../entities/chemicalApplication");
const applicationEventGateway_1 = require("../../gateways/applicationEventGateway");
const createApplication = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const applicationEventGateway = new applicationEventGateway_1.ApplicationEventGateway();
    let { application, accountId } = req.body;
    if (!application.id) {
        const id = `application-${(0, uuid_1.v4)()}`;
        application = Object.assign({ id }, application);
    }
    validate(application);
    //TODO: add application event and application details to database once set up
    yield applicationEventGateway.createApplication(application, accountId);
    const applicationEventResponse = yield applicationEventGateway.createApplicationEvent(application, accountId);
    res.locals.application = applicationEventResponse;
    res.send(res.locals.application);
});
const schema = joi_1.default.object({
    [chemicalApplication_1.ChemicalApplicationFormProperty.ID]: joi_1.default.string().required(),
    [chemicalApplication_1.ChemicalApplicationFormProperty.DATE_OF_APPLICATION]: joi_1.default.string().required(),
    [chemicalApplication_1.ChemicalApplicationFormProperty.AREA_OF_APPLICATION]: joi_1.default.array().items(joi_1.default.string()).required(),
    [chemicalApplication_1.ChemicalApplicationFormProperty.TOTAL_AREA_OF_APP]: joi_1.default.string().pattern(/^[0-9]+$/).required(),
    [chemicalApplication_1.ChemicalApplicationFormProperty.TOTAL_AREA_OF_APP_UNIT]: joi_1.default.string().required(),
    [chemicalApplication_1.ChemicalApplicationFormProperty.TARGET_PESTS]: joi_1.default.array().items(joi_1.default.string()).required(),
    [chemicalApplication_1.ChemicalApplicationFormProperty.CHEMICALS]: joi_1.default.array().items(joi_1.default.object({
        [chemicalApplication_1.ChemicalProperties.CHEMICAL_COMPANY]: joi_1.default.string().required(),
        [chemicalApplication_1.ChemicalProperties.CHEMICAL_NAME]: joi_1.default.string().required(),
        [chemicalApplication_1.ChemicalProperties.AMOUNT]: joi_1.default.string().pattern(/^[0-9]+$/).required(),
        [chemicalApplication_1.ChemicalProperties.UNITS]: joi_1.default.string().required()
    })),
});
const validate = (application) => {
    const { error } = schema.validate(application);
    if (error) {
        throw new Error(`Unable to validate properties of application: ${error}`);
    }
    ;
};
exports.default = createApplication;
//# sourceMappingURL=createApplication.js.map