"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const applicationEventGateway_1 = require("../../gateways/applicationEventGateway");
const getApplicationEvents = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    //TODO get year and accound id from req once it is passed from the client
    const applicationEventGateway = new applicationEventGateway_1.ApplicationEventGateway();
    const applicationEvents = yield applicationEventGateway.getApplicationEventsByYear(2023, 'accountId-123');
    //TODO: get application events once database is set up
    res.locals.events = applicationEvents;
    res.send(res.locals.events);
});
exports.default = getApplicationEvents;
//# sourceMappingURL=getApplicationEvents.js.map