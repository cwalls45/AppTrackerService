"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.combineAreaOfApplication = exports.formatChemicalApplicationToApplicationEvent = void 0;
const formatChemicalApplicationToApplicationEvent = (chemApp) => {
    if (!chemApp.id) {
        throw new Error(`ERROR: There must be an id on ${JSON.stringify(chemApp, null, 2)}`);
    }
    const applicationDate = new Date(chemApp.dateOfApplication);
    console.log;
    return {
        event_id: chemApp.id,
        title: (0, exports.combineAreaOfApplication)(chemApp.areaOfApplication),
        start: applicationDate,
        end: applicationDate,
    };
};
exports.formatChemicalApplicationToApplicationEvent = formatChemicalApplicationToApplicationEvent;
const combineAreaOfApplication = (areas) => {
    return areas.join(', ');
};
exports.combineAreaOfApplication = combineAreaOfApplication;
//# sourceMappingURL=formatChemicalAppToEvent.js.map