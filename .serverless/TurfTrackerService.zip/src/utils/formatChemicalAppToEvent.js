"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.combineAreaOfApplication = exports.formatChemicalApplicationToApplicationEvent = void 0;
const uuid_1 = require("uuid");
const formatChemicalApplicationToApplicationEvent = (chemApp) => {
    const event_id = `application-${(0, uuid_1.v4)()}`;
    const applicationDate = new Date(chemApp.dateOfApplication);
    return {
        event_id,
        title: (0, exports.combineAreaOfApplication)(chemApp.areaOfApplication),
        start: applicationDate,
        end: applicationDate,
    };
};
exports.formatChemicalApplicationToApplicationEvent = formatChemicalApplicationToApplicationEvent;
const combineAreaOfApplication = (areas) => {
    return areas.join(', ');
};
exports.combineAreaOfApplication = combineAreaOfApplication;
//# sourceMappingURL=formatChemicalAppToEvent.js.map