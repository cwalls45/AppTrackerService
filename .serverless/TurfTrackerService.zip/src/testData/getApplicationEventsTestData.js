"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.applicationEventsTestData = void 0;
exports.applicationEventsTestData = [
    {
        event_id: 'application-19b19f03-8559-448b-897c-45931a66f124',
        title: 'Approach',
        start: '2022-12-28T05:00:00.000Z',
        end: '2022-12-28T05:00:00.000Z'
    },
    {
        event_id: 'application-545414adsf-1dafds-fafa008',
        title: 'Approach, Greens',
        start: '2022-12-21T05:00:00.000Z',
        end: '2022-12-21T05:00:00.000Z'
    },
    {
        event_id: 'application-995e5d1d-0489mb.f8d6v-1mflp2a3',
        title: 'Fairway',
        start: '2022-12-29T21:00:00.000Z',
        end: '2022-12-29T21:00:00.000Z'
    },
];
//# sourceMappingURL=getApplicationEventsTestData.js.map