"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChemicalProperties = exports.ChemicalApplicationFormProperty = void 0;
;
;
var ChemicalApplicationFormProperty;
(function (ChemicalApplicationFormProperty) {
    ChemicalApplicationFormProperty["DATE_OF_APPLICATION"] = "dateOfApplication";
    ChemicalApplicationFormProperty["AREA_OF_APPLICATION"] = "areaOfApplication";
    ChemicalApplicationFormProperty["TOTAL_AREA_OF_APP"] = "totalAreaOfApp";
    ChemicalApplicationFormProperty["TOTAL_AREA_OF_APP_UNIT"] = "totalAreaOfAppUnit";
    ChemicalApplicationFormProperty["TARGET_PESTS"] = "targetPests";
    ChemicalApplicationFormProperty["CHEMICALS"] = "chemicals";
})(ChemicalApplicationFormProperty = exports.ChemicalApplicationFormProperty || (exports.ChemicalApplicationFormProperty = {}));
;
var ChemicalProperties;
(function (ChemicalProperties) {
    ChemicalProperties["CHEMICAL_COMPANY"] = "chemicalCompany";
    ChemicalProperties["CHEMICAL_NAME"] = "chemicalName";
    ChemicalProperties["AMOUNT"] = "amount";
    ChemicalProperties["UNITS"] = "units";
})(ChemicalProperties = exports.ChemicalProperties || (exports.ChemicalProperties = {}));
;
//# sourceMappingURL=chemicalApplication.js.map