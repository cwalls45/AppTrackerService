"use strict";
//REFERENCE: https://www.epa.gov/pesticide-labels/pesticide-product-label-system-ppls-application-program-interface-api#api
Object.defineProperty(exports, "__esModule", { value: true });
exports.EPAEndpoint = void 0;
var EPAEndpoint;
(function (EPAEndpoint) {
    EPAEndpoint["EPA_PARTIAL_PRODUCT_NAME"] = "https://ordspub.epa.gov/ords/pesticides/cswu/ProductSearch/partialprodsearch/v2/riname";
    EPAEndpoint["EPA_PRODUCT_NAME"] = "https://ordspub.epa.gov/ords/pesticides/pplstxt";
})(EPAEndpoint = exports.EPAEndpoint || (exports.EPAEndpoint = {}));
;
;
;
//# sourceMappingURL=chemical.js.map