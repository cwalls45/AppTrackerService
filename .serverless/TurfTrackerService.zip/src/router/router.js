"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const createApplication_1 = __importDefault(require("../controllers/chemicalApplication/createApplication"));
const getApplicationEvents_1 = __importDefault(require("../controllers/chemicalApplication/getApplicationEvents"));
const getCompaniesByProductName_1 = __importDefault(require("../controllers/chemicalApplication/getCompaniesByProductName"));
const getPartialChemicalName_1 = __importDefault(require("../controllers/chemicalApplication/getPartialChemicalName"));
const addInventory_1 = __importDefault(require("../controllers/inventory/addInventory"));
const router = express_1.default.Router();
router.get('/applicationEvents/:year/:accountId', getApplicationEvents_1.default);
router.get('/partialChemicalName/:chemical', getPartialChemicalName_1.default);
router.get('/companyNamesByProduct/:productName', getCompaniesByProductName_1.default);
router.post('/createApplication', createApplication_1.default);
router.post('/addInventory', addInventory_1.default);
exports.default = router;
//# sourceMappingURL=router.js.map